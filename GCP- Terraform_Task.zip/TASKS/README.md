1. I created manually the tasks in GCP cloud to know how things run
2. Then i Started with creating with terraform
3. Starting with Creating provider.tf file giving the details of porject ID and region location of the task
4. Then creating the GCP private cluster in kubernetes.tf  and node count, and connected the VPC in cluster as well
5. And created service account with in the same project - myproject01 and nodes with 3 with autoscaling off and node 0 with autoscaling on
6. And created VPC with regional mode - europe-west2 and maximum transmission unit
6. Then cretead private subnet with london location and CIDR range 10.0.0/24
7. Secondary IPV$ range - 10.48.0.0/14, 10.52.0.0/20
8. Then created dataset in dataset.tf as vmo2_tech_test as mentioned in the task2 with automatic speicfic roles assigned to project owner and to my google email address.